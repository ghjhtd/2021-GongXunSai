#ifndef _DATASTORE_H__
#define _DATASTORE_H__


#include "sys.h"


/********************��������******************/
extern void DataStore_Init(void);
extern void StoreTrackData(void);
extern void ReadTrackData(void);
extern u8 CheckData(void);


#endif
